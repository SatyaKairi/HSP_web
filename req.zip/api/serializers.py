from rest_framework import serializers
from django.contrib.auth.models import User
from .models import *

class PasswordResetSerializer(serializers.ModelSerializer):
    class Meta:
        model = PasswordReset
        fields = ['user', 'token', 'timestamp']

class UserSerializer(serializers.ModelSerializer):
    institution_name = serializers.CharField(source='institution.name', read_only=True)
    class Meta:
        model = DhaanaDonationUsers
        fields = ['username', 'email','is_admin','profile_picture','institution','institution_name']
        
        

class DonorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Donor
        fields = '__all__'
        
        
class DonationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Donation
        fields = '__all__'
        
class InstitutionGalarySerializer(serializers.ModelSerializer):
    class Meta:
        model = InstitutionGalary
        fields = ['image', 'title']