from django.shortcuts import render
from rest_framework.views import APIView
from django.contrib.auth import authenticate
from rest_framework.authtoken.models import Token

from api.forms import ResetPasswordForm
from .serializers import *
from rest_framework.response import Response
from rest_framework import viewsets
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated,AllowAny 
from rest_framework import status
from typing import Any
from django.contrib.auth.base_user import AbstractBaseUser
from rest_framework.decorators import action, api_view, permission_classes
from datetime import datetime
from rest_framework import viewsets
from django.db.models import Q
from django.core.mail import send_mail
from django.conf import settings
import uuid
from django.shortcuts import render
from django.http import Http404


# def authenticate(request: Any = ..., **credentials: Any) -> AbstractBaseUser | None: ...

# Create your views here.

class DonationViewSet(viewsets.ModelViewSet):
    serializer_class = DonationSerializer

    def get_queryset(self):
        receipt_from = self.request.query_params.get('receipt_from')
        receipt_to = self.request.query_params.get('receipt_to')
        searchQuery = self.request.query_params.get('searchQuery')
        print(searchQuery)
        queryset = Donation.objects.all()

        if receipt_from and receipt_to:
            receipt_from_date = datetime.strptime(receipt_from, '%Y-%m-%d').date()
            receipt_to_date = datetime.strptime(receipt_to, '%Y-%m-%d').date()
            if searchQuery:
                queryset = queryset.filter(
                    Q(date_receipt__gte=receipt_from_date) &
                    Q(date_receipt__lte=receipt_to_date) &
                    (Q(donation_receipt__icontains=searchQuery) | Q(received_from__icontains=searchQuery))
                )
            else:
                queryset = queryset.filter(Q(date_receipt__gte=receipt_from_date) & Q(date_receipt__lte=receipt_to_date))
        elif searchQuery:
            queryset = queryset.filter(
                    (Q(donation_receipt__icontains=searchQuery) | Q(received_from__icontains=searchQuery))
                )
        return queryset

class UserLoginAPIView(APIView):
    print("Coming here")
    def post(self, request, *args, **kwargs):
        username = request.data.get("username")
        password = request.data.get("password")
        print(username, password)
        user = authenticate(username=username, password=password)
        if user:
            token, created = Token.objects.get_or_create(user=user)
            serializer = UserSerializer(user)
            context={
                "token": token.key,
                "user" : serializer.data,
                
                
            }
            
            return Response(context, status=status.HTTP_200_OK)
        return Response({"detail": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)
    
@permission_classes([IsAuthenticated])
class DonorCreateView(generics.CreateAPIView):
    queryset = Donor.objects.all()
    serializer_class = DonorSerializer
    
# @permission_classes([IsAuthenticated])
class DonationAPIView(APIView):
    def post(self, request, *args, **kwargs):
    
        
        user = request.user  # Assuming you are using TokenAuthentication
        
        print(user)
        print(user.id)
        print(request.data)
        # Include user data in the request.data
        request_data = request.data.copy()
        print(request_data)
        request_data['created_by'] = user.id
        request_data['institution'] = user.institution.id
        
        # request_data['institution'] = user.institution.name  # Assuming user has a related Institution model
        
        serializer = DonationSerializer(data=request_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        print("Validation Errors:", serializer.errors)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    
class ForgotPasswordView(APIView):
    
    
    def post(self, request):
        email = request.data.get('email')
        print("here is the email" + email)
        try:
            user = DhaanaDonationUsers.objects.get(email=email)
        except user.DoesNotExist:
            print("Coming here ")
            return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
    

        # Generate a unique token
        token = str(uuid.uuid4())
        password_reset = PasswordReset.objects.create(user=user, token=token)
        
        # Send email with reset link
        reset_link = f"https://gyan.center/hsp_web/api/reset-password/{token}/"
        # reset_link = f"http://127.0.0.1:8000/api/reset-password/{token}/"
        send_mail(
            'Password Reset',
            f'Click the following link to reset your password: {reset_link}',
            settings.EMAIL_HOST_USER,
            [email],
            fail_silently=False,
        )

        return Response({'message': 'Password reset email sent successfully'}, status=status.HTTP_200_OK)

class ResetPasswordView(APIView):
    def get(self, request, token):
        form = ResetPasswordForm()
        return render(request, 'reset_password.html', {'form': form, 'token': token})
    def post(self, request, token):
        try:
            password_reset = PasswordReset.objects.get(token=token)
        except PasswordReset.DoesNotExist:
            return render(request, 'response.html', {'error': 'Invalid or expired token'})

        new_password = request.data.get('new_password')
        password_reset.user.set_password(new_password)
        password_reset.user.save()

        # Delete the password reset record
        password_reset.delete()

        return render(request, 'response.html', {'message': 'Password reset successful, Please Use this new password to access Dhaana Donation'})
    

class InstitutionGalaryAPIView(generics.ListAPIView):
    serializer_class = InstitutionGalarySerializer

    def get_queryset(self):
        institution_name = self.kwargs['institution_name']
        print (institution_name)
        try:
            institution_galary = InstitutionGalary.objects.filter(institution__name=institution_name)
            if not institution_galary.exists():
                raise Http404("Institution not found")
            return institution_galary
        except Exception as e:
            # Log the exception or handle it based on your requirements
            print(e)
            return None
    
    