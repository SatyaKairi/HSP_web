from django.contrib import admin

# Register your models here.


from django.contrib import admin
from .models import *

admin.site.register(Donor)
admin.site.register(Donation)
admin.site.register(DhaanaDonationUsers)
admin.site.register(Institution)

