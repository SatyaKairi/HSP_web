from django.contrib import admin
from django.urls import path, include
from rest_framework.authtoken.views import obtain_auth_token  # Import the view

from .views import *




urlpatterns = [
    path('user/login/', UserLoginAPIView.as_view(), name='user-login'),
    path('donors/create/', DonorCreateView.as_view(), name='donor-create'),
    path('donations/', DonationAPIView.as_view(), name='donation-api'),
    path('donations/list/', DonationViewSet.as_view({'get': 'list'}), name='donation'), 
    path('forgot-password/', ForgotPasswordView.as_view(), name='forgot-password'),
    path('reset-password/<str:token>/', ResetPasswordView.as_view(), name='reset-password'),
    

]
